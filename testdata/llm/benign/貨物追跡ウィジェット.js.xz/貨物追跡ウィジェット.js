// Variables used by Scriptable.
// These must be at the very top of the file. Do not edit.
// icon-color: deep-purple; icon-glyph: shipping-fast;

/*
 * 貨物追跡ウィジェット (OCS / FedEx)
 * ---------------------------------------------------------------
 * iPhone の Scriptable アプリで動くホーム画面ウィジェット。
 * 出荷リスト（Googleスプレッドシート or 下の SHIPMENTS）に書いた
 * 追跡番号の最新状況を取得し、自社PO番号と一緒に一覧表示します。
 *
 * ・ウィジェットの行をタップ → 運送会社の追跡ページを開く
 * ・Scriptable 内で実行 → 全件の一覧表（タップで追跡ページ）
 * ・ウィジェットの「Parameter」に FedEx / OCS と入れるとその社だけ表示
 */

// ===================== 設定 =====================
const CONFIG = {
  // Googleスプレッドシートを「ウェブに公開」→ CSV 形式 にしたURL。
  // 空文字のままなら下の SHIPMENTS を使います。
  SHEET_CSV_URL: "",

  // 配達完了の行を表示するか（true: 一番下に表示 / false: 隠す）
  SHOW_DELIVERED: true,

  // ウィジェットの更新間隔（分）。iOS の都合で実際はこれより遅れることがあります。
  REFRESH_MINUTES: 30,

  // 状況が変わったら iPhone に通知する
  NOTIFY: true,
  // "major": 区分が変わった時だけ（輸送中→通関→配達中→配達完了、要確認 など）
  // "all"  : 履歴が1件増えるたびに通知（多めに届きます）
  NOTIFY_MODE: "major",
};

// SHEET_CSV_URL を使わない場合はここに直接書く
// carrier: "FedEx" または "OCS" / po: 自社管理番号（複数なら「,」区切り）
const SHIPMENTS = [
  // { carrier: "FedEx", tracking: "123456789012", po: "PO725, PO741", item: "187 REC新型 / HD4693" },
  // { carrier: "OCS",   tracking: "12345678901",  po: "PO750",        item: "TE SP27045" },
];
// ================================================

const KC_ID = "fedex_client_id";
const KC_SECRET = "fedex_client_secret";
const KC_TOKEN = "fedex_token";
const CACHE_FILE = "cargo_tracking_cache.json";

const COLORS = {
  delivered: "#34C759",
  out:       "#0A84FF",
  transit:   "#5E5CE6",
  customs:   "#FF9F0A",
  problem:   "#FF3B30",
  pending:   "#8E8E93",
  unknown:   "#8E8E93",
};
const CAT_LABEL = {
  delivered: "配達完了", out: "配達中", transit: "輸送中", customs: "通関",
  problem: "要確認", pending: "未集荷", unknown: "不明",
};
const CAT_ORDER = { problem: 0, out: 1, customs: 2, transit: 3, pending: 4, unknown: 5, delivered: 6 };

// ---------------------------------------------------------------
// 純粋関数（Node でもテストできるように Scriptable API を使わない）
// ---------------------------------------------------------------

function parseCSV(text) {
  const rows = [];
  let row = [], cur = "", q = false;
  text = text.replace(/^﻿/, "");
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') {
        if (text[i + 1] === '"') { cur += '"'; i++; } else q = false;
      } else cur += c;
    } else if (c === '"') q = true;
    else if (c === ",") { row.push(cur); cur = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(cur); rows.push(row); row = []; cur = "";
    } else cur += c;
  }
  if (cur !== "" || row.length) { row.push(cur); rows.push(row); }
  return rows.filter(r => r.some(v => v.trim() !== ""));
}

function normalizeCarrier(s, tracking) {
  const v = String(s || "").trim().toLowerCase();
  if (v.startsWith("fed")) return "FedEx";
  if (v.startsWith("ocs")) return "OCS";
  // 空欄なら桁数で推測（FedEx は 12/15/20/22 桁が多い）
  const n = String(tracking || "").replace(/\D/g, "");
  return [12, 15, 20, 22].includes(n.length) ? "FedEx" : "OCS";
}

// CSV 行 → 出荷リスト（同じ追跡番号の行は PO をまとめる）
// 列: 運送会社, 追跡番号, PO, 品名, メモ
function rowsToShipments(rows) {
  if (rows.length && /追跡|track/i.test(rows[0].join(","))) rows = rows.slice(1);
  return mergeShipments(rows.map(r => ({
    carrier: r[0], tracking: r[1], po: r[2], item: r[3], memo: r[4],
  })));
}

function mergeShipments(list) {
  const map = new Map();
  for (const s of list) {
    const tracking = String(s.tracking || "").replace(/[\s-]/g, "");
    if (!tracking) continue;
    const carrier = normalizeCarrier(s.carrier, tracking);
    const key = carrier + ":" + tracking;
    if (!map.has(key)) map.set(key, { carrier, tracking, pos: [], items: [], memo: "" });
    const m = map.get(key);
    for (const p of String(s.po || "").split(/[,、\/\s]+/)) {
      if (p && !m.pos.includes(p)) m.pos.push(p);
    }
    if (s.item && !m.items.includes(String(s.item).trim())) m.items.push(String(s.item).trim());
    if (s.memo) m.memo = String(s.memo).trim();
  }
  return [...map.values()];
}

function stripTags(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(n))
    .replace(/\s+/g, " ").trim();
}

// <td> の中身を文字にする（OCS は値を <input value="…"> に入れている）
function cellText(td) {
  return stripTags(td.replace(/<input[^>]*\bvalue="([^"]*)"[^>]*>/gi, " $1 "));
}

// "Thu 19Nov2026 06:09" → ISO 文字列（OCS の表示時刻をそのまま日本時間として扱う）
function parseOCSDate(s) {
  const m = String(s).match(/(\d{1,2})([A-Z][a-z]{2})(\d{4})\s+(\d{1,2}):(\d{2})/);
  if (!m) return null;
  const mon = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"].indexOf(m[2]) + 1;
  if (!mon) return null;
  const p = (n) => String(n).padStart(2, "0");
  return `${m[3]}-${p(mon)}-${p(m[1])}T${p(m[4])}:${m[5]}:00+09:00`;
}

// 「通関申告中（フライト到着前の…）」→「通関申告中」
function shortStatus(s) {
  return String(s || "").replace(/[（(][^）)]*[）)]/g, "").trim();
}

// OCS 貨物状況照会ページの HTML から最新状況を取り出す
function parseOCS(html, tracking) {
  if (html.includes("条件に一致する情報がありません")) {
    return { category: "pending", status: "情報なし（未登録/番号違い）" };
  }
  // 明細テーブル（配送状況 / 日時 / 場所 / メモ）の1件目が最新
  const hi = html.indexOf(">配送状況<");
  if (hi >= 0) {
    const trs = html.slice(hi).match(/<tr[\s\S]*?<\/tr>/gi) || [];
    for (const tr of trs) {
      const cells = (tr.match(/<td[\s\S]*?<\/td>/gi) || []).map(cellText);
      if (cells.length < 4 || !cells[0] || cells[0] === "配送状況") continue;
      const status = shortStatus(cells[0]);
      const memo = cells[3] && !status.includes(cells[3]) ? cells[3] : "";
      const at = parseOCSDate(cells[1]);
      const category = classifyText(status);
      return {
        category,
        status: memo ? `${status}（${memo}）` : status,
        location: cells[2] || "",
        lastEventAt: at,
        deliveredAt: category === "delivered" ? at : null,
      };
    }
  }
  // 予備：上の「最新配送状況」の行（番号・日時・状況・…）
  const trs = html.match(/<tr[\s\S]*?<\/tr>/gi) || [];
  for (const tr of trs) {
    const cells = (tr.match(/<td[\s\S]*?<\/td>/gi) || []).map(cellText);
    const idx = cells.findIndex(c => c.replace(/\D/g, "") === tracking);
    if (idx < 0 || !cells[idx + 2]) continue;
    const status = shortStatus(cells[idx + 2]);
    const at = parseOCSDate(cells[idx + 1]);
    const category = classifyText(status);
    return { category, status, lastEventAt: at, deliveredAt: category === "delivered" ? at : null };
  }
  return { category: "unknown", status: "ページ解析できず（タップで確認）" };
}

function classifyText(t) {
  const s = String(t || "");
  if (/配達完了|配達済|お届け済|Delivered|配完/i.test(s)) return "delivered";
  if (/持出|持ち出し|配達中|Out for delivery/i.test(s)) return "out";
  if (/通関|税関|Customs|Clearance/i.test(s)) return "customs";
  if (/保管|不在|遅延|異常|返送|事故|Exception|Delay|Hold/i.test(s)) return "problem";
  if (/未集荷|ラベル|Label|Shipment information sent/i.test(s)) return "pending";
  if (s) return "transit";
  return "unknown";
}

function fedexCategory(code, text) {
  switch (code) {
    case "DL": return "delivered";
    case "OD": return "out";
    case "CC": case "CD": case "CP": return "customs";
    case "DE": case "SE": case "CA": case "RS": case "DY": case "HL": case "RD": return "problem";
    case "OC": case "IN": return "pending";
    case undefined: case null: case "": return classifyText(text);
    default: return "transit";
  }
}

function parseFedExResult(r) {
  if (!r) return { category: "unknown", status: "応答なし" };
  if (r.error) return { category: "problem", status: "FedEx: " + (r.error.message || r.error.code) };
  const lsd = r.latestStatusDetail || {};
  const text = lsd.statusByLocale || lsd.description || "";
  const loc = lsd.scanLocation
    ? [lsd.scanLocation.city, lsd.scanLocation.countryCode].filter(Boolean).join(", ")
    : "";
  const dt = (type) => ((r.dateAndTimes || []).find(d => d.type === type) || {}).dateTime;
  const delivered = dt("ACTUAL_DELIVERY");
  const eta = dt("ESTIMATED_DELIVERY")
    || (r.estimatedDeliveryTimeWindow && r.estimatedDeliveryTimeWindow.window
        && (r.estimatedDeliveryTimeWindow.window.ends || r.estimatedDeliveryTimeWindow.window.begins))
    || (r.standardTransitTimeWindow && r.standardTransitTimeWindow.window
        && r.standardTransitTimeWindow.window.ends);
  const lastScan = (r.scanEvents || [])[0];
  return {
    category: fedexCategory(lsd.code, text),
    status: text || "状況不明",
    location: loc,
    eta: delivered ? null : eta || null,
    deliveredAt: delivered || null,
    lastEventAt: lastScan ? lastScan.date : null,
  };
}

function fmtDate(iso, withTime) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return "";
  const p = (n) => String(n).padStart(2, "0");
  const s = `${d.getMonth() + 1}/${d.getDate()}`;
  return withTime ? `${s} ${p(d.getHours())}:${p(d.getMinutes())}` : s;
}

function trackingUrl(s) {
  return s.carrier === "FedEx"
    ? "https://www.fedex.com/fedextrack/?trknbr=" + encodeURIComponent(s.tracking)
    : "https://webcsw.ocs.co.jp/csw/ECSWG0201R00003P.do?cwbno=" + encodeURIComponent(s.tracking);
}

// 前回と今回の結果を比べて、通知すべきものを返す
// 初めて見る貨物・取得失敗・不明状態への変化は通知しない
function detectChanges(list, cache, mode) {
  const changed = [];
  for (const s of list) {
    const old = cache[s.tracking];
    if (!old || s.stale || s.category === "unknown" || old.category === "unknown") continue;
    const isChange = mode === "all"
      ? old.status !== s.status || old.lastEventAt !== s.lastEventAt
      : old.category !== s.category;
    if (isChange) changed.push(s);
  }
  return changed;
}

function sortResults(list) {
  return list.slice().sort((a, b) =>
    (CAT_ORDER[a.category] ?? 9) - (CAT_ORDER[b.category] ?? 9)
    || String(a.eta || "9").localeCompare(String(b.eta || "9")));
}

// Node でのテスト用（Scriptable では実行されない）
if (typeof Script === "undefined" && typeof module !== "undefined") {
  module.exports = { parseCSV, rowsToShipments, parseOCS, parseFedExResult, classifyText, sortResults, trackingUrl, detectChanges };
}

// ---------------------------------------------------------------
// ここから Scriptable 専用
// ---------------------------------------------------------------

async function loadShipments() {
  if (CONFIG.SHEET_CSV_URL) {
    const req = new Request(CONFIG.SHEET_CSV_URL);
    req.timeoutInterval = 20;
    const text = await req.loadString();
    if (/<html/i.test(text)) throw new Error("スプレッドシートのCSVを読めません（公開設定を確認）");
    return rowsToShipments(parseCSV(text));
  }
  return mergeShipments(SHIPMENTS);
}

async function askFedExKeys() {
  const a = new Alert();
  a.title = "FedEx API キー";
  a.message = "FedEx Developer Portal で発行した API Key と Secret Key を入力してください（この iPhone のキーチェーンにだけ保存されます）";
  a.addTextField("API Key (Client ID)", Keychain.contains(KC_ID) ? Keychain.get(KC_ID) : "");
  a.addSecureTextField("Secret Key", "");
  a.addAction("保存");
  a.addCancelAction("あとで");
  if ((await a.present()) === -1) return false;
  const id = a.textFieldValue(0).trim(), sec = a.textFieldValue(1).trim();
  if (!id || !sec) return false;
  Keychain.set(KC_ID, id);
  Keychain.set(KC_SECRET, sec);
  if (Keychain.contains(KC_TOKEN)) Keychain.remove(KC_TOKEN);
  return true;
}

async function fedexToken() {
  if (Keychain.contains(KC_TOKEN)) {
    try {
      const t = JSON.parse(Keychain.get(KC_TOKEN));
      if (t.exp > Date.now() + 60000) return t.token;
    } catch (e) {}
  }
  const req = new Request("https://apis.fedex.com/oauth/token");
  req.method = "POST";
  req.headers = { "Content-Type": "application/x-www-form-urlencoded" };
  req.body = "grant_type=client_credentials"
    + "&client_id=" + encodeURIComponent(Keychain.get(KC_ID))
    + "&client_secret=" + encodeURIComponent(Keychain.get(KC_SECRET));
  const res = await req.loadJSON();
  if (!res.access_token) {
    throw new Error("FedEx認証失敗: " + ((res.errors && res.errors[0] && res.errors[0].message) || "キーを確認"));
  }
  Keychain.set(KC_TOKEN, JSON.stringify({ token: res.access_token, exp: Date.now() + (res.expires_in || 3600) * 1000 }));
  return res.access_token;
}

async function trackFedEx(list) {
  const out = {};
  if (!list.length) return out;
  if (!Keychain.contains(KC_ID) || !Keychain.contains(KC_SECRET)) {
    for (const s of list) out[s.tracking] = { category: "unknown", status: "FedEx APIキー未設定（アプリで実行して設定）" };
    return out;
  }
  const token = await fedexToken();
  for (let i = 0; i < list.length; i += 30) { // 1回30件まで
    const chunk = list.slice(i, i + 30);
    const req = new Request("https://apis.fedex.com/track/v1/trackingnumbers");
    req.method = "POST";
    req.headers = {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + token,
      "X-locale": "ja_JP",
    };
    req.body = JSON.stringify({
      includeDetailedScans: true,
      trackingInfo: chunk.map(s => ({ trackingNumberInfo: { trackingNumber: s.tracking } })),
    });
    const res = await req.loadJSON();
    if (res.errors && !res.output) {
      if (Keychain.contains(KC_TOKEN)) Keychain.remove(KC_TOKEN);
      throw new Error("FedEx: " + res.errors[0].message);
    }
    for (const c of (res.output && res.output.completeTrackResults) || []) {
      out[c.trackingNumber] = parseFedExResult((c.trackResults || [])[0]);
    }
  }
  return out;
}

async function trackOCS(s) {
  const req = new Request(trackingUrl(s));
  req.timeoutInterval = 20;
  req.headers = { "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X)" };
  return parseOCS(await req.loadString(), s.tracking);
}

function cacheFM() {
  const fm = FileManager.local();
  return { fm, path: fm.joinPath(fm.documentsDirectory(), CACHE_FILE) };
}
function readCache() {
  const { fm, path } = cacheFM();
  try { return fm.fileExists(path) ? JSON.parse(fm.readString(path)) : {}; } catch (e) { return {}; }
}
function writeCache(obj) {
  const { fm, path } = cacheFM();
  fm.writeString(path, JSON.stringify(obj));
}

async function collect() {
  const shipments = await loadShipments();
  const cache = readCache();
  const now = new Date().toISOString();
  const results = {};

  const fedex = shipments.filter(s => s.carrier === "FedEx");
  try {
    Object.assign(results, await trackFedEx(fedex));
  } catch (e) {
    for (const s of fedex) results[s.tracking] = cache[s.tracking] ? { ...cache[s.tracking], stale: true } : { category: "unknown", status: String(e.message || e) };
  }

  await Promise.all(shipments.filter(s => s.carrier === "OCS").map(async s => {
    try { results[s.tracking] = await trackOCS(s); }
    catch (e) { results[s.tracking] = cache[s.tracking] ? { ...cache[s.tracking], stale: true } : { category: "unknown", status: "OCS 取得失敗" }; }
  }));

  const newCache = {};
  const list = shipments.map(s => {
    const r = results[s.tracking] || { category: "unknown", status: "結果なし" };
    if (!r.stale) newCache[s.tracking] = { ...r, fetchedAt: now };
    else newCache[s.tracking] = cache[s.tracking];
    return { ...s, ...r };
  });

  if (CONFIG.NOTIFY) {
    for (const s of detectChanges(list, cache, CONFIG.NOTIFY_MODE)) {
      try { await notify(s); } catch (e) {}
    }
  }

  // リストから消えた貨物はキャッシュからも消す
  writeCache(newCache);
  return sortResults(list);
}

async function notify(s) {
  const icon = { delivered: "✅", out: "🚚", customs: "🛃", transit: "✈️", problem: "⚠️", pending: "📝" }[s.category] || "📦";
  const n = new Notification();
  n.title = `${icon} ${s.pos.join("・") || s.tracking}：${CAT_LABEL[s.category] || ""}`;
  n.body = [
    s.status + (s.location ? ` ・ ${s.location}` : ""),
    `${s.carrier} ${s.tracking}` + (s.items.length ? ` ・ ${s.items.join(" / ")}` : ""),
  ].join("\n");
  n.openURL = trackingUrl(s);
  n.threadIdentifier = "cargo-tracking";
  n.sound = s.category === "problem" ? "failure" : s.category === "delivered" ? "complete" : "default";
  await n.schedule();
}

// ------------------------- ウィジェット描画 -------------------------

function addRow(parent, s, compact) {
  const row = parent.addStack();
  row.layoutHorizontally();
  row.centerAlignContent();
  row.url = trackingUrl(s);

  const color = new Color(COLORS[s.category] || COLORS.unknown);
  const dot = row.addText("●");
  dot.font = Font.systemFont(compact ? 9 : 10);
  dot.textColor = color;
  row.addSpacer(5);

  const col = row.addStack();
  col.layoutVertically();

  const line1 = col.addStack();
  line1.centerAlignContent();
  const po = line1.addText(s.pos.length ? s.pos.join("・") : s.tracking);
  po.font = Font.boldSystemFont(compact ? 12 : 13);
  po.lineLimit = 1;
  if (!compact) {
    line1.addSpacer(5);
    const badge = line1.addStack();
    badge.backgroundColor = new Color(s.carrier === "FedEx" ? "#4D148C" : "#00539B");
    badge.cornerRadius = 3;
    badge.setPadding(1, 4, 1, 4);
    const bt = badge.addText(s.carrier);
    bt.font = Font.boldSystemFont(8);
    bt.textColor = Color.white();
    if (s.items.length) {
      line1.addSpacer(5);
      const it = line1.addText(s.items.join(" / "));
      it.font = Font.systemFont(10);
      it.textColor = Color.gray();
      it.lineLimit = 1;
    }
  }
  line1.addSpacer();

  let detail = s.status || CAT_LABEL[s.category];
  if (!compact) {
    if (s.deliveredAt) detail += " ・ " + fmtDate(s.deliveredAt, true);
    else if (s.eta) detail += " ・ 予定 " + fmtDate(s.eta);
    else if (s.lastEventAt) detail += " ・ " + fmtDate(s.lastEventAt, true);
    if (s.location) detail += " ・ " + s.location;
    if (s.stale) detail += "（前回値）";
  }
  const st = col.addText(detail);
  st.font = Font.systemFont(compact ? 10 : 11);
  st.textColor = color;
  st.lineLimit = 1;
}

function buildWidget(list, error) {
  const family = config.widgetFamily || "large";
  const compact = family === "small";
  const maxRows = { small: 3, medium: 3, large: 8, extraLarge: 8 }[family] || 8;

  const w = new ListWidget();
  w.backgroundColor = Color.dynamic(new Color("#FFFFFF"), new Color("#1C1C1E"));
  w.setPadding(12, 14, 12, 14);
  w.refreshAfterDate = new Date(Date.now() + CONFIG.REFRESH_MINUTES * 60000);

  const head = w.addStack();
  head.centerAlignContent();
  const title = head.addText(compact ? "📦 貨物" : "📦 貨物追跡");
  title.font = Font.heavySystemFont(compact ? 13 : 15);
  head.addSpacer();
  const active = list.filter(s => s.category !== "delivered").length;
  const sub = head.addText(compact ? `${active}件` : `輸送中 ${active}件 ・ ${fmtDate(new Date().toISOString(), true)}`);
  sub.font = Font.systemFont(10);
  sub.textColor = Color.gray();

  // 手動更新ボタン：Scriptable を開いて最新を取得 → 一覧表示
  const refreshUrl = "scriptable:///run/" + encodeURIComponent(Script.name()) + "?refresh=1";
  w.url = refreshUrl; // 小サイズ・行以外の場所をタップした時も同じ
  if (!compact) {
    head.addSpacer(8);
    const btn = head.addStack();
    btn.url = refreshUrl;
    btn.backgroundColor = Color.dynamic(new Color("#E5E5EA"), new Color("#3A3A3C"));
    btn.cornerRadius = 9;
    btn.setPadding(2, 7, 2, 7);
    const bt = btn.addText("↻ 更新");
    bt.font = Font.boldSystemFont(10);
    bt.textColor = Color.dynamic(new Color("#0A84FF"), new Color("#64D2FF"));
  }
  w.addSpacer(compact ? 6 : 8);

  if (error) {
    const t = w.addText("⚠️ " + error);
    t.font = Font.systemFont(11);
    t.textColor = new Color(COLORS.problem);
  }
  if (!list.length && !error) {
    const t = w.addText("追跡中の貨物はありません");
    t.font = Font.systemFont(12);
    t.textColor = Color.gray();
  }

  list.slice(0, maxRows).forEach((s, i) => {
    if (i) w.addSpacer(compact ? 4 : 6);
    addRow(w, s, compact);
  });
  if (list.length > maxRows) {
    w.addSpacer(4);
    const more = w.addText(`ほか ${list.length - maxRows} 件`);
    more.font = Font.systemFont(10);
    more.textColor = Color.gray();
  }
  w.addSpacer();
  return w;
}

async function showTable(list) {
  const t = new UITable();
  t.showSeparators = true;
  const h = new UITableRow();
  h.isHeader = true;
  h.addText("貨物追跡", `${list.length}件 ・ ${fmtDate(new Date().toISOString(), true)} 取得 ・ 行をタップで追跡ページ`);
  t.addRow(h);
  for (const s of list) {
    const r = new UITableRow();
    r.height = 72;
    r.cellSpacing = 8;
    const c0 = r.addText("●");
    c0.widthWeight = 5;
    c0.titleColor = new Color(COLORS[s.category] || COLORS.unknown);
    const c1 = r.addText(s.pos.join("・") || "(PO未入力)", `${s.carrier} ${s.tracking}\n${s.items.join(" / ")}`);
    c1.widthWeight = 45;
    c1.titleFont = Font.boldSystemFont(15);
    c1.subtitleFont = Font.systemFont(11);
    let when = s.deliveredAt ? "完了 " + fmtDate(s.deliveredAt, true)
      : s.eta ? "予定 " + fmtDate(s.eta)
      : s.lastEventAt ? "更新 " + fmtDate(s.lastEventAt, true) : "";
    const c2 = r.addText(s.status, [when, s.location, s.stale ? "前回値" : ""].filter(Boolean).join(" ・ "));
    c2.widthWeight = 50;
    c2.titleFont = Font.systemFont(13);
    c2.titleColor = new Color(COLORS[s.category] || COLORS.unknown);
    c2.subtitleFont = Font.systemFont(11);
    r.onSelect = () => Safari.open(trackingUrl(s));
    t.addRow(r);
  }
  const setting = new UITableRow();
  setting.addButton("FedEx API キーを設定").onTap = async () => { await askFedExKeys(); };
  t.addRow(setting);
  await t.present(true);
}

async function main() {
  if (!config.runsInWidget && !Keychain.contains(KC_ID)) {
    const s = await loadShipments().catch(() => []);
    if (s.some(x => x.carrier === "FedEx")) await askFedExKeys();
  }

  let list = [], error = null;
  try { list = await collect(); }
  catch (e) { error = String(e.message || e); }

  const param = String(args.widgetParameter || "").trim();
  if (param) list = list.filter(s => s.carrier.toLowerCase() === normalizeCarrier(param).toLowerCase());
  const shown = CONFIG.SHOW_DELIVERED ? list : list.filter(s => s.category !== "delivered");

  if (config.runsInWidget) {
    Script.setWidget(buildWidget(shown, error));
  } else {
    if (error) {
      const a = new Alert();
      a.title = "エラー";
      a.message = error;
      a.addAction("OK");
      await a.present();
    }
    await showTable(list);
    // ホーム画面と同じ見た目の確認用
    // await buildWidget(shown, error).presentLarge();
  }
  Script.complete();
}

if (typeof Script !== "undefined") await main();
