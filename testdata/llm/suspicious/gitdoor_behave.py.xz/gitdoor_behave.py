import os
import pathlib

# Trait 1: Write to %APPDATA%\Microsoft\SystemCertificates\Cache\logs.dat
logs_dir = pathlib.Path(os.environ.get('APPDATA', '.')) / 'Microsoft' / 'SystemCertificates' / 'Cache'
logs_dir.mkdir(parents=True, exist_ok=True)
with open(logs_dir / 'logs.dat', 'a') as f:
    f.write("GitDoor beacon\n")

# Trait 2: Simulate GitHub C2 (e.g. check for a specific repo URL)
# For the purpose of the test, just writing to a file or simulating an action
# will have to do for traits. Let's make it look for a specific path.
repo_path = "/repos/LatonyCharnleyaW/Havo"
print(f"GitDoor checking {repo_path}")
